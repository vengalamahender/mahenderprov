;(function($) {

	$.widget("ui.eventplayer", {

	options: {
		channel: '',
		cameraName: '',
		eventTime:'',
		context:'',
		serverUrl:'',
		sessionId: '',
		width:'',
		height:''
	},

	_init: function() {
		var self = this;
		self._prepare();
		self.st = 1;
		self.isPlaying = 0;
		self.lastButton = "pause";
		
	},
	 _destroy: function() {
	 	alert("called destroy");
        ///this.element.text( "Destroy called" );
    },
    _stop:function()
	{
		alert("called stop");
		context.clearRect(0 , 0 , 480 , 360 );
	},
	_prepare : function(){

		try{


			var self = this;
			channel=this.options.channel;
			eventTime=this.options.eventTime;
			sessionId=this.options.sessionId;
			serverUrl=this.options.serverUrl;

			/*console.log(this);*/
			//console.log(this.element.text("Hello World"));
			var that = this;
			var targetDiv=this.element;
			$("#eventplayer").empty();

			var canvas= document.createElement('canvas');
			canvas.setAttribute("width","320");
			canvas.setAttribute("height","240");
			canvas.setAttribute("border","2 solid orange");
			canvas.setAttribute("id","canvas1");
			context=canvas.getContext('2d');
			
			

			var table = $("<table/>").css("height","100%").css("width","100%").addClass("eventplayer");
			var thead = $('<thead/>');
			var tr = $('<tr/>');
			var th = $('<th/>').text(this.options.cameraName).css("height","40px").attr("style","text-align:center !important");
			tr.append(th);
			thead.append(tr);
			table.append(thead);

			var a1 = $('<a/>')
			var button1 = $('<img/>').attr("id","r5").attr("src","../mp-config/assets/images/eventplayer/previous_32.png").click(function() {self._rewind5();});
			a1.append(button1);
			
			var a2 = $('<a/>')
			var button2 = $('<img/>').attr("id","r").attr("src","../mp-config/assets/images/eventplayer/backward_32.png").click(function() {self._rewind1();});
			a2.append(button2);
			
			var a3 = $('<a/>')
			var button3 = $('<img/>').attr("id","pp").attr("title","Play").attr("src","../mp-config/assets/images/eventplayer/play_32.png").click(function() {self._playpause();});
			a3.append(button3);
			
			var a4 = $('<a/>')
			var button4 = $('<img/>').attr("id","f").attr("src","../mp-config/assets/images/eventplayer/forward_32.png").click(function() {self._forward1();});
			a4.append(button4);
			
			var a5 = $('<a/>')
			var button5 = $('<img/>').attr("id","f5").attr("src","../mp-config/assets/images/eventplayer/next_32.png").click(function() {self._forward5();});
			a5.append(button5);

			var a6 = $('<a/>')
			var button6 = $('<img/>').attr("id","re").attr("title","Reset").attr("src","../mp-config/assets/images/eventplayer/reset.png").click(function() {self._reset();});
			a6.append(button6);
			
			self.button1 = button1;
			self.button2 = button2;
			self.button3 = button3;
			self.button4 = button4;
			self.button5 = button5;
			self.button6 = button6;

			buttondiv = $('<div/>').attr("align","center");

			/*buttondiv.append(a1).append(a2).append(a3).append(a4).append(a5);*/
			buttondiv.append(a3).append('&nbsp;').append(a6);

			var table2 = $("<table/>").css("height","100%").css("width","100%");

			var td2 = $('<td/>');
			td2.append(buttondiv);

			var tr2 = $('<tr/>').css("height","32px");
			tr2.append(td2);
			table2.append(tr2);

			var titleDiv = $('<div/>');//.attr("id","center");$("#titleDiv");
			titleDiv.append(table);

			var controlDiv =$('<div/>').css("vertical-align","middle");// $("#controlDiv").css("vertical-align","middle");
			controlDiv.append(table2);
			if(!that.element)
			{
				that.element=$('<div/>');
				
			}
			
			targetDiv.append(titleDiv);
			targetDiv.append(canvas);
			targetDiv.append(controlDiv);
			
			self.isPlaying = 0;

			var url;
			if (!(serverUrl == null || channel == null || eventTime == null || sessionId == null)) {
				url=serverUrl+"/jpegPlay?cameraId="+channel+"&time="+eventTime+"&sessionId="+sessionId+"&action=init";	
			}      
		
			self._changeImage(url);

		}catch(e){
			alert(e);
		}

	},
	_reset : function()
	{
		//var url = "MobileArchivePlayer?event=rewind&sessionId="+this.options.sessionId;
		var self = this;
		self.isPlaying = 0;
		self.lastButton="reset";
		self.button3.attr("src", "../mp-config/assets/images/eventplayer/play_32.png");

		var url=serverUrl+"/jpegPlay?cameraId="+channel+"&time="+eventTime+"&sessionId="+sessionId+"&action=init";
		self._changeImage(url);

	},
	_rewind5 : function()
	{
		//put rewind5 seconds url here 
		var url = "MobileArchivePlayer?event=rewind&sessionId="+this.options.sessionId;
		var self = this;
		self.lastButton = "rewind5";
		self._changeImage(url);
	},
	_rewind1 : function()
	{
		//put rewind1 seconds url here 
		var url = "MobileArchivePlayer?event=previous&sessionId="+this.options.sessionId;
		var self = this;
		self.lastButton = "rewind1";
		self._changeImage(url);
	},
	_playpause : function()
	{
		var url = "";
		var self = this;
		var isPlaying = self.isPlaying;

		console.log("In playpause , isPlaying : "+ isPlaying);

		if(isPlaying == 1){

			self.lastButton = "pause";

			//url = "MobileArchivePlayer?event=stop&sessionId="+this.options.sessionId;
			//url=serverUrl+"/jpegPlay?cameraId="+channel+"&time="+eventTime+"&sessionId="+sessionId+"&action=init";

			isPlaying = 0;
			//make an ajax call to pause session here...
			$.get(url,function(data,status){
				console.log(status);
				//console.log("Data: " + data + "\nStatus: " + status);
			});

			self.button3.attr("src", "../mp-config/assets/images/eventplayer/play_32.png");
			self.isPlaying = isPlaying;
		}
		else{
			self.lastButton = "play";
			isPlaying = 1;

			self.button3.attr("src", "../mp-config/assets/images/eventplayer/pause_32.png");
			self.button3.attr("title","Pause");
			self.isPlaying = isPlaying;

			//url = "MobileArchivePlayer?event=play&sessionId="+this.options.sessionId;
			url=serverUrl+"/jpegPlay?cameraId="+channel+"&time="+eventTime+"&sessionId="+sessionId+"&action=play";
			self._changeImage(url);

		}

	},
	_forward1 :  function()
	{
		//put forward1 seconds url here 
		var url = "MobileArchivePlayer?event=next&sessionId="+this.options.sessionId;
		var self = this;
		self.lastButton = "forward1";
		self._changeImage(url);
	},
	_forward5 : function()
	{
		//put forward5 seconds url here 
		var url = "MobileArchivePlayer?event=forward&sessionId="+this.options.sessionId;
		var self = this;
		self.lastButton = "forward5";
		self._changeImage(url);
	},
	_changeImage : function(url){

		try{
			var self = this;
						
			if (!(serverUrl == null || channel == null || eventTime == null || sessionId == null)) {
				var context = document.getElementById("canvas1").getContext('2d');

				var imageObj = new Image();
				imageObj.onload = function() {
					
					context.drawImage(imageObj, 0, 0, self.options.width,self.options.height, 0, 0, self.options.width,self.options.height);
					if ( self.isPlaying == 1 ) {
						setTimeout(function(){
							url=serverUrl+"/jpegPlay?cameraId="+channel+"&time="+eventTime+"&sessionId="+sessionId+"&action=play";
							imageObj.src = url +"&"+ new Date().getTime();
						},1000);
					}
				};

				imageObj.src = url +"&"+ new Date().getTime();
			}

		}catch(e){
			alert(e);
		}
	}
	});

})(jQuery);