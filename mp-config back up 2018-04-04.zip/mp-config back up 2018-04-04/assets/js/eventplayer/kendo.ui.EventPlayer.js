(function($) {

	 // shorten references to variables. this is better for uglification 
	var kendo = window.kendo,
        ui = kendo.ui,
        Widget = ui.Widget,
        channel='',
        cameraName='',
        sessionId='',
        serverUrl='',
        cameraObj,
        context,th;
    var EventPlayer = Widget.extend({

		options: {
		name:"EventPlayer",
		channel: '',
		cameraName: '',
		sessionId: '',
		cameraObj:'',
		url:''
	},	
	stop:function()
	{
		context.clearRect(0 , 0 , 480 , 360 );
		/*th.text("");*/
	},
	refresh:function(cameraId,camName,sessId,siteUrl,cameraObj)
	{
		var that=this;
		var isPlaying=false;
		if(that.isPlaying==1)
			isPlaying=true;
		that.isPlaying=0;
		that.button3.attr("src", "images/eventplayer/play_32.png");
		console.log("Stopped...");
		channel=cameraId;
		cameraName=camName;
		sessionId=sessId;
        serverUrl=siteUrl;
        cameraObj=cameraObj;
        //cameraObj=that.options.cameraObj
        console.log(cameraObj);
		var url = serverUrl+"/MobileArchivePlayer?event=init&sessionId="+sessId;
		if(isPlaying)
		{
			setTimeout(function(){that._changeImage(url) },1100);
		}
		else
			that._changeImage(url);
		/*th.text(camName);*/
//		console.log("Refreshed...started...");

	},

	init: function(element, options) {
		 Widget.fn.init.call(this, element, options);
		var that = this;
		channel=this.options.channel;
		cameraName=this.options.cameraName;
		sessionId=this.options.sessionId;
		serverUrl=this.options.url;
		cameraObj=this.options.cameraObj;
		that._prepare();
		that.isPlaying = 0;
		that.lastButton = "pause";
		
	},

	_prepare : function(){

		try{

			var that = this;
			var targetDiv=this.element;
			var table = $("<table/>").css("height","100%").css("width","100%").addClass("its");
			var thead = $('<thead/>');
			var tr = $('<tr/>');
			/*th = $('<th/>').text(cameraName).css("height","16px").attr("align","center");*/
			tr.append(th);
			thead.append(tr);
			table.append(thead);

				$("#eventplayer").css("visibility","visible");
			var a1 = $('<a/>').attr("href","#");
			var button1 = $('<img/>').attr("id","r5").attr("src","images/eventplayer/previous_32.png").click(function() {that._rewind5();});
			a1.append(button1);
			
			var a2 = $('<a/>').attr("href","#");
			var button2 = $('<img/>').attr("id","r").attr("src","images/eventplayer/backward_32.png").click(function() {that._rewind1();});
			a2.append(button2);
			
			var a3 = $('<a/>').attr("href","#");
			var button3 = $('<img/>').attr("id","pp").attr("src","images/eventplayer/play_32.png").click(function() {that._playpause();});
			a3.append(button3);
			
			var a4 = $('<a/>').attr("href","#");
			var button4 = $('<img/>').attr("id","f").attr("src","images/eventplayer/forward_32.png").click(function() {that._forward1();});
			a4.append(button4);
			
			var a5 = $('<a/>').attr("href","#");
			var button5 = $('<img/>').attr("id","f5").attr("src","images/eventplayer/next_32.png").click(function() {that._forward5();});
			a5.append(button5);
			
			that.button1 = button1;
			that.button2 = button2;
			that.button3 = button3;
			that.button4 = button4;
			that.button5 = button5;

			buttondiv = $('<div/>').attr("align","center");

			buttondiv.append(a1).append(a2).append(a3).append(a4).append(a5);

			var table2 = $("<table/>").css("height","100%").css("width","100%");

			var td2 = $('<td/>');
			td2.append(buttondiv);

			var tr2 = $('<tr/>').css("height","32px");
			tr2.append(td2);
			table2.append(tr2);

			var titleDiv = $('<div/>');//.attr("id","center");$("#titleDiv");
			titleDiv.append(table);

			var controlDiv =$('<div/>').css("vertical-align","middle");// $("#controlDiv").css("vertical-align","middle");
			controlDiv.append(table2);
			if(!that.element)
			{
				that.element=$('<div/>');
				
			}
			var canvas= document.createElement('canvas');
			canvas.setAttribute("width","490");
			canvas.setAttribute("height","380");
			context=canvas.getContext('2d');
			targetDiv.append(titleDiv);
			targetDiv.append(canvas);
			targetDiv.append(controlDiv);
			that.isPlaying = 0;

			var url = serverUrl+"/MobileArchivePlayer?event=init&sessionId="+sessionId;
			that._changeImage(url);

		}catch(e){
			alert(e);
		}

	},

	_rewind5 : function()
	{
		//put rewind5 seconds url here 
		var url = serverUrl+"/MobileArchivePlayer?event=rewind&sessionId="+sessionId;
		var that = this;
		that.lastButton = "rewind5";
		that._changeImage(url);
	},
	_rewind1 : function()
	{
		//put rewind1 seconds url here 
		var url = serverUrl+"/MobileArchivePlayer?event=previous&sessionId="+sessionId;
		var that = this;
		that.lastButton = "rewind1";
		that._changeImage(url);
	},
	_playpause : function()
	{
		var url = "";
		var that = this;
		var isPlaying = that.isPlaying;

//		console.log("In playpause , isPlaying : "+ isPlaying);

		if(isPlaying == 1){

			that.lastButton = "pause";

			url = serverUrl+"/MobileArchivePlayer?event=stop&sessionId="+sessionId;

			isPlaying = 0;
			//make an ajax call to pause session here...
			$.get(url,function(data,status){
//				console.log("Data: " + data + "\nStatus: " + status);
			});

			that.button3.attr("src", "images/eventplayer/play_32.png");
			that.isPlaying = isPlaying;
		}
		else{
			that.lastButton = "play";
			isPlaying = 1;

			that.button3.attr("src", "images/eventplayer/pause_32.png");
			that.isPlaying = isPlaying;

			url = serverUrl+"/MobileArchivePlayer?event=play&sessionId="+sessionId;
			that._changeImage(url);

		}

	},
	_forward1 :  function()
	{
		//put forward1 seconds url here 
		var url = serverUrl+"/MobileArchivePlayer?event=next&sessionId="+sessionId;
		var that = this;
		that.lastButton = "forward1";
		that._changeImage(url);
	},
	_forward5 : function()
	{
		//put forward5 seconds url here 
		var url = serverUrl+"/MobileArchivePlayer?event=forward&sessionId="+sessionId;
		var that = this;
		that.lastButton = "forward5";
		that._changeImage(url);
	},
	_changeImage : function(url){

		try{
			console.log(cameraObj);
			
			var that = this;
			
			if(cameraObj!=null && cameraObj.streamingType!=null && cameraObj.streamingType=="VIDEOSERVER"){
				url=cameraObj.streamingUrl+"/jpegPlay?cameraId="+cameraObj.cameraId+"&motionEnabled=true&action=play&sessionId="+sessionId;
			}

			var imageObj = new Image();
			imageObj.onload = function() {
				context.drawImage(imageObj , 0 , 0 , 320 , 240,0,0, 480 , 360 );
				if ( that.isPlaying == 1 ) {
					setTimeout(function(){
						imageObj.src = url +"&"+ new Date().getTime();
					},1000);
				}
			};

			imageObj.src = url +"&"+ new Date().getTime();		
		}catch(e){
			alert(e);
		}
	}
	});
	ui.plugin(EventPlayer);

})(jQuery);
